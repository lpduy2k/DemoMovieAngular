import { Injectable } from '@angular/core';
import { Movie, MovieDetail } from '../models/movie';

import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  // Không cần import vào trong mảng providers ở AppModule khi có providedIn: 'root'
  providedIn: 'root',
})
export class MovieService {
  constructor(private http: HttpClient) {}

  getMovieList(): Observable<Movie[]> {
    const url = `https://movie0706.cybersoft.edu.vn/api/QuanLyPhim/LayDanhSachPhim`;

    let params = new HttpParams();
    params = params.append('maNhom', 'GP01');
    // params = page ? params.append('maNhom', 'GP01') : params

    return this.http.get<Movie[]>(url, { params });
  }

  getMovieDetail(movieId: string): Observable<MovieDetail> {
    const url = `https://movie0706.cybersoft.edu.vn/api/QuanLyPhim/LayThongTinPhim`;

    let params = new HttpParams();
    params = params.append('maPhim', movieId);

    return this.http.get<MovieDetail>(url, { params });
  }

  // getMovieListPromise(): Promise<Movie[]> {
  //   return new Promise((resolve, reject) => {
  //     setTimeout(() => {
  //       // reject('Error fetching')
  //       resolve([
  //         {
  //           id: 1,
  //           name: 'Avengers',
  //           price: 80000,
  //           image: 'assets/img/avengers.jpeg',
  //         },
  //         {
  //           id: 2,
  //           name: 'Wonder Woman',
  //           price: 80000,
  //           image: 'assets/img/wonder-woman.jpeg',
  //         },
  //         {
  //           id: 3,
  //           name: 'One punch man',
  //           price: 80000,
  //           image: 'assets/img/one-punch-man.jpeg',
  //         },
  //         {
  //           id: 4,
  //           name: 'Fast and Furious',
  //           price: 80000,
  //           image: 'assets/img/fast-and-furious.jpeg',
  //         },
  //       ]);
  //     }, 2000);
  //   });
  // }

  // getMovieListObservable(): Observable<Movie[]> {
  //   return new Observable((subscribe) => {
  //     setTimeout(() => {
  //       // subscribe.error('Fetching error')

  //       subscribe.next([
  //         {
  //           id: 1,
  //           name: 'Avengers',
  //           price: 80000,
  //           image: 'assets/img/avengers.jpeg',
  //         },
  //         {
  //           id: 2,
  //           name: 'Wonder Woman',
  //           price: 80000,
  //           image: 'assets/img/wonder-woman.jpeg',
  //         },
  //         {
  //           id: 3,
  //           name: 'One punch man',
  //           price: 80000,
  //           image: 'assets/img/one-punch-man.jpeg',
  //         },
  //         {
  //           id: 4,
  //           name: 'Fast and Furious',
  //           price: 80000,
  //           image: 'assets/img/fast-and-furious.jpeg',
  //         },
  //       ]);

  //       subscribe.complete();
  //     }, 2000);
  //   });
  // }
}
