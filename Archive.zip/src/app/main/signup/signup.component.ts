import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss'],
})
export class SignupComponent implements OnInit {
  @ViewChild('signupForm') signupForm!: NgForm;

  constructor(private auth: AuthService) {}

  ngOnInit(): void {}

  handleSignup() {
    if (this.signupForm.invalid) return;

    console.log(this.signupForm.value);
    this.auth.signup(this.signupForm.value).subscribe();
  }
}
