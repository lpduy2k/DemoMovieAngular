import { Component } from '@angular/core';

@Component({
  selector: 'app-root', // Tên component sẽ nhúng vào html
  // Khai báo file html của component
  templateUrl: './app.component.html',
  // Khai báo file css/scss của component
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'fe54-angular';
}
